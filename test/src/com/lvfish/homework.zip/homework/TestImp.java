package com.lvfish.homework;

public interface TestImp {
    void testTransaction();

    void testLog();

    void testLogAndTransaction();


    void testWithoutAnnotation();
}
